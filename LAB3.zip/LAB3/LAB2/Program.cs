﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB2
{
    class Program
    {
        static void Main()
        {
            First();
            Second();
            //Th();
            Vosem();
        }
        static void First()
        {
            double x, y;
            int sum = 0;
            x = int.Parse(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
                sum += Convert.ToInt32(Math.Log(i * x));
            y = 2 * sum + Math.Pow(x, 5);
            Console.WriteLine("{0:f8}", y);
        }


        static void Second()
        {
            double z, x;
            double p = 1;
            x = int.Parse(Console.ReadLine());
            for (int k = 1; k <= 5; k++)
                p *= Math.Sin(k*x);
            z = p + 2;
            Console.WriteLine("{0:f8}", z);
        }


        static void Th()//2.15
        {
            //int x=0, m=0;
            double S=0, step, znak;

            //Console.Write("Введите x:");
            double x = 0.2;
            //Console.Write("Введите m:");
            int m = 10;

            for (int i = 1; i<=m;i++)
            {
                znak = Math.Pow(-1, i - 1);
                step = Math.Pow(x, i);
                S = S + znak * step / i;
            }
            double r = S - Math.Log(1 + x);
            Console.WriteLine("{0:f30}", r);
        }

        static void Vosem()//2.8
        {
            double S = 1, step, znak;

            Console.WriteLine("Введите x:");
            double x = Convert.ToDouble(Console.ReadLine());
            //double x = 0.9;

            int n = 50;

            for (int i = 1; i<=n; i++)
            {
                znak = Math.Pow(-1, i);
                step = Math.Pow(x, i);
                S = S + znak * step;
            }

            double r = S - (1/(1+x));
            Console.WriteLine("{0:f30}", r);
        }
    }
}
