import sys
x = int(input())
y = int(input())
z = int(input())
if (x==0 and y==0 and z==0):
    print('Нет решения')
    sys.exit()
if (x<y):
    if (x<z):min1=x
    else:
        if(y<z):min1=y
        else:min1=z
else:
    if(x<z):min1=y
    else:
        if(y<z):min1=y
        else:min1=z
        
if (x>z):max1=x
else:max1=z
f=(min1+x)/(pow(max1,2)+y)

if (f==0):
    print ('f=0')
else:
    print ('f=',f)

#if (x<y) ? if (x<z)? min1==x :if(y<z)? min1==y : min1=z :if(x<z)?min1==y:if(y<z)?min1==y:min1==z
#if (x>y)? max1==x:max1==y
