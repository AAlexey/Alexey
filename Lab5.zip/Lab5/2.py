x=int(input())
y=int(input())

if(x>=0):
    if (y>0): print('N=3')
    elif (y<0): print('N=4')
    else: print('M(0;0)')
if (x<0):
    if((pow(x,2)+ pow(y,2))<=64):
        if(y>0): print('N=1')
        elif (y<0): print('N=2')
        else: print ('x=0') 
    else:
        if (y>0): print('N=3')
        elif (y<0): print('N=4')
        else: print ('y=0') 
	
